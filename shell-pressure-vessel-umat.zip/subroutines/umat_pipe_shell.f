      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
C
C     ISOTROPIC LINEAR ELASTIC UMAT
C     Handles two cases, selected automatically from NDI/NSHR/NTENS
C     that Abaqus passes in for the active element type:
C
C     (A) 3D solids (C3D8) and axisymmetric solids (CAX4):
C         NDI=3, NTENS=6 or 4  -> general 3D isotropic elasticity
C
C     (B) Shells (S4R), membranes, and plane-stress elements:
C         NDI=2, NSHR=1, NTENS=3 (components 11, 22, 12)
C         -> generalized PLANE STRESS elasticity
C
C     Using the general 3D stiffness for case (B) would silently give
C     PLANE-STRAIN stiffness instead of plane stress, since a naive
C     block-extraction of the 3D matrix is NOT the same as the
C     plane-stress-reduced matrix. This branch avoids that mistake.
C
C     PROPS(1) = E   (Young's modulus)
C     PROPS(2) = NU  (Poisson's ratio)
C
      INCLUDE 'ABA_PARAM.INC'
C
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
C
      EMOD=PROPS(1)
      ENU=PROPS(2)
C
      DO K1=1,NTENS
        DO K2=1,NTENS
          DDSDDE(K2,K1)=0.0
        END DO
      END DO
C
      IF (NSHR.EQ.1 .AND. NDI.EQ.2) THEN
C
C       ------------------------------------------------------------
C       CASE (B): GENERALIZED PLANE STRESS (shells, membranes)
C       Components ordered: 1=11, 2=22, 3=12 (engineering shear)
C       ------------------------------------------------------------
        EPS=EMOD/(1.0-ENU*ENU)
        DDSDDE(1,1)=EPS
        DDSDDE(2,2)=EPS
        DDSDDE(1,2)=EPS*ENU
        DDSDDE(2,1)=EPS*ENU
        DDSDDE(3,3)=EMOD/(2.0*(1.0+ENU))
C
      ELSE
C
C       ------------------------------------------------------------
C       CASE (A): GENERAL 3D / AXISYMMETRIC ISOTROPIC ELASTICITY
C       ------------------------------------------------------------
        EBULK3=EMOD/(1.0-2.0*ENU)
        EG2=EMOD/(1.0+ENU)
        EG=EG2/2.0
        ELAM=(EBULK3-EG2)/3.0
C
        DO K1=1,NDI
          DO K2=1,NDI
            DDSDDE(K2,K1)=ELAM
          END DO
          DDSDDE(K1,K1)=EG2+ELAM
        END DO
C
        DO K1=NDI+1,NTENS
          DDSDDE(K1,K1)=EG
        END DO
C
      END IF
C
C     UPDATE STRESS: STRESS = STRESS + DDSDDE : DSTRAN
      DO K1=1,NTENS
        DO K2=1,NTENS
          STRESS(K2)=STRESS(K2)+DDSDDE(K2,K1)*DSTRAN(K1)
        END DO
      END DO
C
C     NO STATE VARIABLE EVOLUTION NEEDED FOR LINEAR ELASTICITY
C
      RETURN
      END
