# Shell Pressure Vessel — UMAT Verification Model

An Abaqus/Standard finite element model of a thin-walled cylindrical pressure
vessel, modeled with shell elements and driven by a custom UMAT (user
material subroutine), used to verify closed-form thin-wall pressure vessel
theory (hoop and axial stress) against finite element results.

## Geometry & Loading

| Parameter              | Value        |
|-------------------------|--------------|
| Midsurface radius, R     | 250 mm       |
| Wall thickness, t        | 2 mm         |
| Length, L                | 1000 mm      |
| Internal pressure, P     | 30 MPa       |
| Material                 | Isotropic, E = 210000 MPa, ν = 0.3 |

One end of the vessel is fully encastre (all 6 shell DOFs fixed). The other
end is free, with an equivalent axial line load applied to represent a
closed end cap.

## Target (analytical) results

For a thin-walled cylinder (R/t = 125, well within the thin-wall
assumption):

- **Hoop stress:** σ_θ = P·R / t = 30 × 250 / 2 = **3750 MPa**
- **Axial stress:** σ_z = P·R / (2t) = 30 × 250 / 4 = **1875 MPa**

The axial line load is derived directly from these formulas
(`w = P·R/2`, in force/length), so the shell model should reproduce both
values essentially exactly — see `docs/theory.md` for the full derivation.

## Repository structure

```
input/
  pipe_shell.inp        Abaqus input deck (176 nodes, 160 S4R shell elements)
subroutines/
  umat_pipe_shell.f      UMAT: isotropic elasticity, with a plane-stress
                          branch for shells/membranes and a general 3D/
                          axisymmetric branch for solid/CAX elements
docs/
  theory.md               Derivation of the hoop/axial stress targets and
                          notes on the UMAT plane-stress branch
results/
  (Abaqus output files go here — ignored by git, see .gitignore)
```

## Model details

- **Element type:** S4R (4-node, reduced-integration shell)
- **Mesh:** 16 elements around the circumference, 10 along the length
- **Section:** `*Shell Section`, thickness = 2 mm, with an explicit
  `*Transverse Shear Stiffness` (required because Abaqus cannot compute
  this automatically from a `*User Material`)
- **Boundary condition:** `*Boundary, ENCASTRE` on the ring of nodes at
  the fixed end
- **Loads:**
  1. Internal pressure (30 MPa) applied via `*Dsload` on an explicit
     `*Surface` (SPOS face) — required because Abaqus needs a declared
     surface for shell pressure loads, not just an element set.
  2. Equivalent axial line load at the free end, applied as lumped nodal
     forces (`*Cload`) representing `w = P·R/2` distributed around the
     circumference.

## Running the model

Requires Abaqus/Standard with a linked Fortran compiler.

```bash
abaqus job=pipeshell input=input/pipe_shell.inp user=subroutines/umat_pipe_shell.f
```

Move or copy the job's output files (`.odb`, `.dat`, `.msg`, `.sta`, etc.)
into `results/` once the run completes (this folder is git-ignored by
default — remove the relevant line in `.gitignore` if you want to version
specific result files).

## Checking the results

In the Abaqus/CAE Visualization module (or via the `.odb`), check:

- **S11** (hoop direction, local shell axis 1) at mid-length, away from the
  boundary effects near the fixed end → should read ≈ 3750 MPa
- **S22** (axial direction, local shell axis 2) at mid-length → should read
  ≈ 1875 MPa

Expect some local disturbance near the encastre end (a boundary-layer
effect familiar from shell theory) that decays within roughly
`~2.5·sqrt(R·t)` of the fixed edge — this is expected shell behavior, not
a modeling error, and results away from that zone should match the
closed-form solution closely.

## Notes on the UMAT

Abaqus calls a UMAT differently depending on the element type:

- **Shells / membranes / plane stress:** `NDI=2, NSHR=1, NTENS=3`
  (components 11, 22, 12) — the material response must be the
  **plane-stress-reduced** stiffness, not a block of the 3D stiffness
  matrix (using the 3D block would silently give plane-strain behavior
  instead, and the results would not match the target formulas).
- **3D solids / axisymmetric solids:** `NDI=3`, general isotropic
  elasticity.

`umat_pipe_shell.f` branches on `NDI`/`NSHR` to handle both cases
correctly, so it also works if you swap in a solid or axisymmetric mesh
using the same material constants.

## License

See `LICENSE`.
