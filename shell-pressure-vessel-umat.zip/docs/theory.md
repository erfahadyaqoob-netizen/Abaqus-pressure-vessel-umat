# Theory Notes

## 1. Thin-wall pressure vessel formulas

For a thin-walled cylindrical vessel (radius-to-thickness ratio R/t large,
here R/t = 125) under internal pressure P, closed at both ends:

- Hoop (circumferential) stress:  σ_θ = P·R / t
- Axial (longitudinal) stress:    σ_z = P·R / (2t)

These come from a simple force-balance free-body diagram:

- **Hoop stress:** cut the cylinder along its length; the pressure acting
  on the projected internal area (2R·L) must be balanced by the hoop
  stress acting on the two cut wall cross-sections (2·t·L):
  `P·(2R·L) = σ_θ·(2t·L)  =>  σ_θ = P·R/t`

- **Axial stress:** cut the cylinder perpendicular to its axis; the
  pressure acting on the internal cross-sectional (bore) area (π·R²)
  must be balanced by the axial stress acting on the wall's annular
  cross-section (≈ 2π·R·t for a thin wall):
  `P·(π·R²) = σ_z·(2π·R·t)  =>  σ_z = P·R/(2t)`

## 2. Why a shell model, not a solid model, gives the *exact* result

A solid (continuum) model has a real inner radius Ri and outer radius Ro,
so its "exact" axial stress (computed from the true bore area and true
wall cross-sectional area) is slightly different from the thin-wall
formula — the two only converge as t/R → 0.

A shell model is defined entirely at the midsurface radius R with
thickness carried as a section property, so there's no Ri/Ro
discretization — the shell's geometry already matches the thin-wall
assumption exactly. That's why this model targets the classical
formulas directly rather than a "corrected" version.

## 3. The equivalent axial line load

Rather than computing a total cap force and splitting it (as needed for
a solid model, since it has a real bore area), the shell model applies
the axial resultant directly as a line load (force per unit length of
circumference):

```
w = σ_z · t = (P·R/(2t)) · t = P·R/2
```

This is applied as lumped nodal forces at the free-end nodes:

```
F_node = w · (2πR / n_nodes)
```

The sum of all F_node values equals P·π·R² exactly — the same total force
a real end cap would see from internal pressure.

## 4. UMAT: general 3D vs. plane stress

Abaqus's UMAT interface passes different `NDI` (number of direct stress
components) and `NSHR` (number of shear components) depending on element
type:

| Element type                  | NDI | NSHR | NTENS | Components         |
|--------------------------------|-----|------|-------|---------------------|
| 3D solid (C3D8)                 | 3   | 3    | 6     | 11,22,33,12,13,23   |
| Axisymmetric solid (CAX4)       | 3   | 1    | 4     | 11,22,33,12         |
| Shell / membrane / plane stress | 2   | 1    | 3     | 11,22,12            |

For the shell case, the through-thickness stress (33) is enforced to be
zero (plane stress), and the correct isotropic stiffness is:

```
D11 = D22 = E / (1 - ν²)
D12 = D21 = E·ν / (1 - ν²)
D33 (shear) = E / (2(1+ν))
```

Simply extracting the top-left 2×2 block of the general 3D isotropic
stiffness matrix does **not** give this — it gives the plane-**strain**
reduction instead, which is stiffer and would not reproduce the P·R/t
and P·R/(2t) targets. `umat_pipe_shell.f` branches on `NDI`/`NSHR` to
apply the correct formulation for whichever element type calls it.
